package com.cookandroid.problem4_7;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;


public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Button button=findViewById(R.id.button);

        CheckBox checkBox1 = (CheckBox) findViewById(R.id.checkBox1) ;
        checkBox1.setOnClickListener(new CheckBox.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (((CheckBox)v).isChecked()) {
                    button.setEnabled(true);
                } else {
                    button.setEnabled(false);
                }
            }
        }) ;
        CheckBox checkBox2 = (CheckBox) findViewById(R.id.checkBox2) ;
        checkBox2.setOnClickListener(new CheckBox.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (((CheckBox)v).isChecked()) {
                    button.setClickable(true);
                } else {
                    button.setClickable(false);
                }
            }
        }) ;
        CheckBox checkBox3 = (CheckBox) findViewById(R.id.checkBox3) ;
        checkBox3.setOnClickListener(new CheckBox.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (((CheckBox)v).isChecked()) {
                    button.setRotation(45);
                } else {
                    button.setRotation(0);
                }
            }
        }) ;
    }
}